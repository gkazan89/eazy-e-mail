# -*- coding: utf-8 -*-
"""
Created on Tue Jan  2 15:05:51 2018

@author: gkazan
"""

#email html code blocks

        


#test service manager info
"""list1=[
      ("white kia", "Walter White","\"mailto:heisenberg@kia.com", "Walt"),
      
      ("pinkman kia", "Jesse Pinkman","\"mailto:capncook@kia.com", "Jesse")
]"""

"""print(your_list)"""


#opens csv data file
import csv

#takes csv and turns it into a list
with open('leslie2.csv', 'r') as f:
  reader = csv.reader(f)
  your_list = list(reader)


#assign data to correct list item
#prints html code with values
for (store,sm,email,name) in your_list:     
    print(first + store + second 
          + sm + third + mailto + email 
          + subject + name + lm + mailto
          + email + subject + name 
          + dnh + mailto + email 
          + subject + name + custom)
    




    



