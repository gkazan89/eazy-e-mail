# -*- coding: utf-8 -*-
"""
Created on Tue Jan  2 15:05:51 2018

@author: gkazan
"""

#wayy smaller email html code blocks!


one ="""var email=('""" #emailaddress

two ="""');

var name= ('Hi%20""" #name
           
three ="""');

document.write('<tr><td>""" #store

four ="""</td><td>""" #servmanager

five ="""</td><td>'+'<a href="mailto:' + email +

'?subject=' +subject+

'&body=' +name+ greetingOne +body+ signature+

linkOne+'</td>');

document.write( '<td><a href="mailto:' + email +

'?subject=' +subject+

'&body=' +name+ greetingTwo+ body+ signature+

linkTwo + '</td>');

document.write( '<td><a href="mailto:' + email +

'?subject=' +subject+

'&body=' +name+ signature+

linkThree + '</td></tr>');"""


#test service manager info
"""list1=[
      ("white kia", "Walter White","\"mailto:heisenberg@kia.com", "Walt"),
      
      ("pinkman kia", "Jesse Pinkman","\"mailto:capncook@kia.com", "Jesse")
]"""

"""print(your_list)"""


#opens csv data file
import csv

#takes csv and turns it into a list
with open('wendy.csv', 'r') as f:
  reader = csv.reader(f)
  your_list = list(reader)


#assign data to correct list item
#prints html code with values
for (store,sm,email,name) in your_list:     
    print(one+email+two+name+three+store+four+sm+five)
    

#email= """mcren@nwa.com"""
#
#name= """Ice Cube"""
#
#sm="""MC REN"""
#
#store="""Straight Outta Kia"""
#
#print(one+email+two+name+three+store+four+sm+five)


#email name store sm





    



